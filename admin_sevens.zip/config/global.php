<?php 
//Ip de la pc servidor de base de datos
define("DB_HOST","http://208.109.75.99");

//Nombre de la base de datos
define("DB_NAME", "bd_sevens_test");

//Usuario de la base de datos
define("DB_USERNAME", "sevens_ingenieros_test");

//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "T9EpGfkPHY9T9gg");

//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","bd_sevens_test");
?>