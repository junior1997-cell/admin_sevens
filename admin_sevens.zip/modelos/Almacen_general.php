<?php
//Incluímos inicialmente la conexión a la base de datos
require "../config/Conexion_v2.php";

class Almacen_general
{
  //Implementamos nuestro variable global
  public $id_usr_sesion;

  //Implementamos nuestro constructor
  public function __construct($id_usr_sesion = 0)
  {
    $this->id_usr_sesion = $id_usr_sesion;
  }

  //Implementamos un método para insertar registros
  public function insertar($nombre, $descripcion)
  {

    $sql = "SELECT nombre_almacen, descripcion, estado, estado_delete FROM almacen_general WHERE nombre_almacen = '$nombre';";
    $buscando = ejecutarConsultaArray($sql);
    if ($buscando['status'] == false) {
      return $buscando;
    }

    if (empty($buscando['data'])) {
      $sql = "INSERT INTO almacen_general(nombre_almacen, descripcion, user_created ) VALUES ('$nombre','$descripcion', '$this->id_usr_sesion')";
      $insertar =  ejecutarConsulta_retornarID($sql,'C');
      return $insertar;
    } else {
      $info_repetida = '';

      foreach ($buscando['data'] as $key => $value) {
        $info_repetida .= '<li class="text-left font-size-13px">
          <b>Nombre: </b>' . $value['nombre_almacen'] . '<br>
          <b>Descripcion: </b>' . $value['descripcion'] . '<br>            
          <b>Papelera: </b>' . ($value['estado'] == 0 ? '<i class="fas fa-check text-success"></i> SI' : '<i class="fas fa-times text-danger"></i> NO') . '<br>
          <b>Eliminado: </b>' . ($value['estado_delete'] == 0 ? '<i class="fas fa-check text-success"></i> SI' : '<i class="fas fa-times text-danger"></i> NO') . '<br>
          <hr class="m-t-2px m-b-2px">
        </li>';
      }
      $sw = array('status' => 'duplicado', 'message' => 'duplicado', 'data' => '<ul>' . $info_repetida . '</ul>', 'id_tabla' => '');
      return $sw;
    }
  }

  //Implementamos un método para editar registros
  public function editar($idalmacen_general, $nombre, $descripcion)
  {
    $sql = "UPDATE almacen_general SET nombre_almacen='$nombre', descripcion='$descripcion', user_updated = '$this->id_usr_sesion'
		WHERE idalmacen_general = '$idalmacen_general';";
    $editar =  ejecutarConsulta($sql,'U');
    return $editar;
  }

  //Implementamos un método para desactivar categorías
  public function desactivar($idalmacen_general)
  {

    $sql = "UPDATE almacen_general SET estado='0',user_trash= '$this->id_usr_sesion'  WHERE idalmacen_general ='$idalmacen_general'";
    $desactivar = ejecutarConsulta($sql,'T');

    return $desactivar;
  }

  //Implementamos un método para eliminar
  public function eliminar($idalmacen_general)
  {
    $sql = "UPDATE almacen_general SET estado_delete='0',user_delete= '$this->id_usr_sesion' WHERE idalmacen_general ='$idalmacen_general'";
    $eliminar =  ejecutarConsulta($sql,'D');

    return $eliminar;
  }

  //Implementar un método para mostrar los datos de un registro a modificar
  public function mostrar($idalmacen_general)
  {
    $sql = "SELECT idalmacen_general, nombre_almacen, descripcion
    FROM almacen_general WHERE idalmacen_general ='$idalmacen_general'; ";
    return ejecutarConsultaSimpleFila($sql);
  }

  //Implementar un método para listar los registros
  public function tabla_principal()
  {
    $sql = "SELECT idalmacen_general, nombre_almacen, descripcion, estado, estado_delete 
    FROM almacen_general WHERE estado='1' AND estado_delete='1' ORDER BY nombre_almacen ASC;";
    return ejecutarConsulta($sql);
  }

  //Implementar un método para listar los registros
  public function tabla_detalle($id_proyecto, $id_almacen)
  {
    $sql = "SELECT agr.idalmacen_general_resumen,agr.tipo,agr.total_stok,agr.total_ingreso,agr.total_egreso, ag.idalmacen_general,p.nombre as nombre_producto, um.nombre_medida as unidad_medida,um.abreviacion, c.nombre as categoria
    FROM almacen_general_resumen AS agr
    INNER JOIN almacen_general as ag on agr.idalmacen_general = ag.idalmacen_general
    -- INNER JOIN almacen_resumen as ar on agr.idalmacen_resumen=ar.idalmacen_resumen
    INNER JOIN producto as p on agr.idproducto = p.idproducto
    INNER JOIN unidad_medida um on p.idunidad_medida=um.idunidad_medida
    INNER JOIN categoria_insumos_af c on p.idcategoria_insumos_af=c.idcategoria_insumos_af
    WHERE agr.idalmacen_general='$id_almacen' AND agr.estado = '1' AND agr.estado_delete = '1'";
    return ejecutarConsulta($sql);
  }

  public function tabla_detalle_almacen_general($idalmacen_general, $idalmacen_general_resumen)
  {
    // var_dump($idalmacen_general); die();
    $sql = "SELECT 
    ad.idalmacen_general_detalle, 
    ad.idalmacen_general_resumen, 
    ad.idalmacen_general_destino, 
    ad.idproyecto, 
    ad.tipo_mov,
    CASE ad.tipo_mov
        WHEN 'IEA' THEN 'INGRESO ENTRE ALMACENES'
        WHEN 'EEA' THEN 'EGRESO ENTRE ALMACENES'
        WHEN 'IGP' THEN 'INGRESO A ALMACEN GENERAL DE PROYECTO'
        WHEN 'EGP' THEN 'EGRESO DE ALMACEN GENERAL E INGRESO A UN PROYECTO'
    END AS tipo_movimiento ,
    ad.fecha, 
    ad.name_day, 
    ad.name_month, 
    ad.name_year, 
    CASE ad.tipo_mov
        WHEN 'IEA' THEN ad.cantidad
        WHEN 'EEA' THEN -1*ad.cantidad
        WHEN 'IGP' THEN ad.cantidad
        WHEN 'EGP' THEN -1*ad.cantidad
    END AS cantidad, 
    ad.stok_anterior, 
    ad.stok_actual,
    CASE ad.tipo_mov
        WHEN 'IEA' THEN agd.nombre_almacen
        WHEN 'EEA' THEN agd.nombre_almacen
        WHEN 'IGP' THEN p.nombre_codigo
        WHEN 'EGP' THEN p.nombre_codigo
    END AS nombre_proyecto_almacen
  FROM almacen_general_detalle ad
  LEFT JOIN Proyecto p ON ad.idproyecto = p.idproyecto
  LEFT JOIN almacen_general agd ON ad.idalmacen_general_destino = agd.idalmacen_general
  INNER JOIN almacen_general_resumen as agr on agr.idalmacen_general_resumen=ad.idalmacen_general_resumen
  where agr.idalmacen_general = '$idalmacen_general' and agr.idalmacen_general_resumen='$idalmacen_general_resumen';";

    return ejecutarConsultaArray($sql);
  }
  //Seleccionar Trabajador Select2
  public function lista_de_categorias()
  {
    $sql = "SELECT idalmacen_general as idcategoria, nombre_almacen as nombre 
    FROM almacen_general WHERE estado='1' AND estado_delete='1' ; ";
    return ejecutarConsultaArray($sql);
  }

  //------------------------------------------------------------------------------------
  // ------------ ADD PRODUCTOS DE PROYECTOS A UN ALMACEN GENERAL  ---------------------
  //------------------------------------------------------------------------------------

  public function select2_recursos_almacen($idproyecto)
  {
    $sql = "SELECT ar.idalmacen_resumen,ar.idproyecto,ar.idproducto,ar.tipo,ar.total_egreso,ar.total_stok,ar.total_ingreso, p.nombre as nombre_producto, 
    um.nombre_medida as unidad_medida,um.abreviacion, c.nombre as categoria
    FROM almacen_resumen as ar
    INNER JOIN producto as p on ar.idproducto=p.idproducto
    INNER JOIN unidad_medida um on p.idunidad_medida=um.idunidad_medida
    INNER JOIN categoria_insumos_af c on p.idcategoria_insumos_af=c.idcategoria_insumos_af
    where ar.idproyecto='$idproyecto' and ar.total_stok>'0' ORDER BY p.nombre ASC;";
    return ejecutarConsultaArray($sql);
  }

  //----------- Insertar productos a almacen general ,-------$id_ar_ag = id_almacen_resumen
  public function insertar_alm_general(
    $idalmacen_general_ag,
    $fecha_ingreso_ag,
    $dia_ingreso,
    $idproducto_ag,
    $proyecto_ag,
    $id_almacen_resumen,
    $cantidad_ag,
    $stok,
    $t_egreso,
    $t_ingreso,
    $tipo_mov
  ) {

    $ii = 0;

    if (!empty($id_almacen_resumen)) {

      while ($ii < count($idproducto_ag)) {

        //=================A L M A C E N  P O R  P R O Y E C T O =====================

        //ACTUALIZAMOS EL ALMACEN_RESUMEN
        $sql = "UPDATE almacen_resumen SET total_stok= total_stok - $cantidad_ag[$ii] , total_egreso= total_egreso + $cantidad_ag[$ii], 
        user_updated='$this->id_usr_sesion' WHERE idalmacen_resumen='$id_almacen_resumen[$ii]';";

        $ar = ejecutarConsulta($sql,'U');
        if ($ar['status'] == false) {
          return $ar;
        }

        //REGISTRAMOS EL EGRESO EN  ALMACEN_DETALLE
        $sql_alm_detall = "INSERT INTO almacen_detalle(idalmacen_resumen, idalmacen_general, tipo_mov, fecha, cantidad, stok_anterior, stok_actual) 
        VALUES ('$id_almacen_resumen[$ii]','$idalmacen_general_ag','EPG','$fecha_ingreso_ag','$cantidad_ag[$ii]','$stok[$ii]','$cantidad_ag[$ii]-$stok[$ii]')";

        $sql_alm_det = ejecutarConsulta($sql_alm_detall,'C');
        if ($sql_alm_det['status'] == false) {
          return $sql_alm_det;
        }
        //=================F I N  A L M A C E N  P O R  P R O Y E C T O ====================

        $sql_validate = "SELECT idalmacen_general_resumen,idalmacen_general,idproducto 
        FROM almacen_general_resumen where idalmacen_general='$idalmacen_general_ag' and idproducto='$idproducto_ag[$ii]' ";

        $validate = ejecutarConsultaSimpleFila($sql_validate);
        if ($validate['status'] == false) {
          return $validate;
        }

        if (!empty($validate['data'])) {

          $idalmacen_general_r = $validate['data']['idalmacen_general_resumen'];
          $idalmacen           = $validate['data']['idalmacen_general'];
          $id_producto_r = $validate['data']['idproducto'];
        } else {
          $idalmacen_general_r = null;
          $idalmacen           = null;
          $id_producto_r       = null;
        }

        if (!empty($idalmacen_general_r) &&  !empty($idalmacen) && !empty($id_producto_r) && $idalmacen = $idalmacen_general_ag  && $id_producto_r = $idproducto_ag[$ii]) {

          //ACTUALIZAMOS EL QUE YA EXISTE
          $sql_update = "UPDATE almacen_general_resumen SET 
          idalmacen_general='$idalmacen_general_ag', idproducto='$idproducto_ag[$ii]', total_stok=total_stok + $cantidad_ag[$ii],
          total_ingreso=total_ingreso+ $cantidad_ag[$ii], user_updated='$this->id_usr_sesion'
          WHERE idalmacen_general_resumen='$idalmacen_general_r'";

          $sql_alm_detalle = ejecutarConsulta($sql_update,'U');

          if ($sql_alm_detalle['status'] == false) {
            return $sql_alm_detalle;
          }

          //Registramos un nuevo detalle
          $sql_create_det = "INSERT INTO almacen_general_detalle( idalmacen_general_resumen, idproyecto, tipo_mov, fecha,cantidad, user_created) 
          VALUES ('$idalmacen_general_r','$proyecto_ag[$ii]','IGP','$fecha_ingreso_ag','$cantidad_ag[$ii]','$this->id_usr_sesion')";
          $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

          if ($sql_alm_det_gen['status'] == false) {
            return $sql_alm_det_gen;
          }

        } else {

          //AGREGAMOS UNO NUEVO
          $sql_nuevo = "INSERT INTO almacen_general_resumen(idalmacen_general, idproducto, tipo, total_stok, total_ingreso, user_created) 
          VALUES ('$idalmacen_general_ag','$idproducto_ag[$ii]','$tipo_mov[$ii]','$cantidad_ag[$ii]','$cantidad_ag[$ii]','$this->id_usr_sesion')";
          $sql_new_regist = ejecutarConsulta_retornarID($sql_nuevo,'C');

          if ($sql_new_regist['status'] == false) {
            return $sql_new_regist;
          }

          $idalm_general_resumen = $sql_new_regist['data'];

          //Registramos un nuevo detalle
          $sql_create_det = "INSERT INTO almacen_general_detalle( idalmacen_general_resumen, idproyecto, tipo_mov, fecha,cantidad, user_created) 
          VALUES ('$idalm_general_resumen','$proyecto_ag[$ii]','IGP','$fecha_ingreso_ag','$cantidad_ag[$ii]','$this->id_usr_sesion')";
          $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

          if ($sql_alm_det_gen['status'] == false) {
            return $sql_alm_det_gen;
          }
        }

        $ii = $ii + 1;
      }
      return $retorno = ['status' => true, 'message' => 'todo oka ps', 'data' => ''];
    }


    return $retorno = ['status' => true, 'message' => 'todo oka ps', 'data' => ''];
  }

  //-----------------------------------------------------------------------------------------------------------------
  // ----------- T R A N S F E R E N C I A S  A   P R O Y E C T O S   Y   A L M A C E N  G E N E R A L --------------
  //-----------------------------------------------------------------------------------------------------------------


  public function guardar_transf_almacen_proyecto(
    $tranferencia,
    $name_alm_proyecto,
    $fecha_transf_proy_alm,
    $idalmacen_general_origen,
    $idalmacen_general_trns,
    $idalmacen_general_resumen_trns,
    $idproducto_trns,
    $tipo_trns,
    $categoria_trns,
    $cantidad_trns,
    $ValorCheck_trns
  ) {

    if (!empty($tranferencia) && $tranferencia == "Otro_Almacen") {
      //enviamos otro almacen
      $ii = 0;

      // var_dump($tipo_trns); die();
      if (!empty($idalmacen_general_resumen_trns)) {

        while ($ii < count($idalmacen_general_resumen_trns)) {

          if ($ValorCheck_trns[$ii] == '1') {

            //ACTUALIZAMOS EN EL ALMACEN ORIGEN
            $sql_update = "UPDATE almacen_general_resumen SET 
            total_stok=total_stok - $cantidad_trns[$ii], total_egreso=total_egreso+ $cantidad_trns[$ii], user_updated='$this->id_usr_sesion'         
            WHERE idalmacen_general_resumen='$idalmacen_general_resumen_trns[$ii]' 
            and idproducto='$idproducto_trns[$ii]' 
            and idalmacen_general='$idalmacen_general_trns[$ii]'";

            $sql_alm_detalle = ejecutarConsulta($sql_update,'U');
            if ($sql_alm_detalle['status'] == false) {
              return $sql_alm_detalle;
            }

            //REGISTRAMOS LA SALIDA DEL ALAMACEN ORIGEN
            $sql_create_det = "INSERT INTO almacen_general_detalle( idalmacen_general_resumen, idalmacen_general_destino, tipo_mov, fecha,cantidad, user_created) 
            VALUES ('$idalmacen_general_resumen_trns[$ii]','$name_alm_proyecto','EEA','$fecha_transf_proy_alm','$cantidad_trns[$ii]','$this->id_usr_sesion')";
            $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

            if ($sql_alm_det_gen['status'] == false) {
              return $sql_alm_det_gen;
            }
            
            //REGISTRO  AL NUEVO ALMACEN

            //Verificamos si hay el producto en el almacen nuevo 
            $sql_verif = "SELECT * FROM almacen_general_resumen WHERE idalmacen_general='$name_alm_proyecto' and idproducto='$idproducto_trns[$ii]'";
            $r_verficar = ejecutarConsultaSimpleFila($sql_verif);

            if ($r_verficar['status'] == false) {
              return $r_verficar;
            }
            if (!empty($r_verficar['data'])) {

              $idalmacen_general_r = $r_verficar['data']['idalmacen_general_resumen'];
              $idalmacen           = $r_verficar['data']['idalmacen_general'];
              $id_producto_r = $r_verficar['data']['idproducto'];
            } else {
              $idalmacen_general_r = null;
              $idalmacen           = null;
              $id_producto_r       = null;
            }

            if (!empty($idalmacen_general_r) &&  !empty($idalmacen) && !empty($id_producto_r) && $idalmacen = $name_alm_proyecto  && $id_producto_r = $idproducto_trns[$ii]) {

              //ACTUALIZAMOS EL QUE YA EXISTE
              $sql_update = "UPDATE almacen_general_resumen SET 
              total_stok=total_stok + $cantidad_trns[$ii], total_ingreso=total_ingreso + $cantidad_trns[$ii], 
              user_updated='$this->id_usr_sesion' WHERE idalmacen_general_resumen='$idalmacen_general_r'";

              $sql_alm_detalle = ejecutarConsulta($sql_update,'U');
              if ($sql_alm_detalle['status'] == false) {
                return $sql_alm_detalle;
              }

              //Registramos un nuevo detalle
              $sql_create_det = "INSERT INTO almacen_general_detalle( idalmacen_general_resumen, idalmacen_general_destino, tipo_mov, fecha,cantidad, user_created) 
              VALUES ('$idalmacen_general_r','$idalmacen_general_origen','IEA','$fecha_transf_proy_alm','$cantidad_trns[$ii]','$this->id_usr_sesion')";
              $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

              if ($sql_alm_det_gen['status'] == false) {
                return $sql_alm_det_gen;
              }

            } else {

              //AGREGAMOS UNO NUEVO
              $sql_nuevo = "INSERT INTO almacen_general_resumen(idalmacen_general, idproducto, tipo, total_stok, total_ingreso, user_created) 
              VALUES ('$name_alm_proyecto','$idproducto_trns[$ii]','$tipo_trns[$ii]','$cantidad_trns[$ii]','$cantidad_trns[$ii]','$this->id_usr_sesion')";
              $sql_new_regist = ejecutarConsulta_retornarID($sql_nuevo,'C');

              if ($sql_new_regist['status'] == false) {
                return $sql_new_regist;
              }

              $idalm_general_resumen = $sql_new_regist['data'];

              //Registramos un nuevo detalle
              $sql_create_det = "INSERT INTO almacen_general_detalle( idalmacen_general_resumen, idalmacen_general_destino,  tipo_mov, fecha,cantidad, user_created) 
              VALUES ('$idalm_general_resumen','$idalmacen_general_origen','IEA','$fecha_transf_proy_alm','$cantidad_trns[$ii]','$this->id_usr_sesion')";
              $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

              if ($sql_alm_det_gen['status'] == false) {
                return $sql_alm_det_gen;
              }
            }
          }
          $ii = $ii + 1;
        }
        return $retorno = ['status' => true, 'message' => 'todo oka ps', 'data' => ''];
      }


      // -----------------------------
      //ACTUALIZAR EL ALMACEN RESUMEN GENERAL ... listo
      //REGISTRAR EN EL DETALLE LA SALIDA .... Listo
      //REGISTRAR EL INGRESO AL NUEVO ALMACEN 
      //rEGISTRAR EL DETALLE DEL INGRESO AL ALMACEN

    } else {
      //enviamos producto a un almacen de proyecto

      $ii = 0;

      //  var_dump('proyect'); die();
      if (!empty($idalmacen_general_resumen_trns)) {

        while ($ii < count($idalmacen_general_resumen_trns)) {

          if ($ValorCheck_trns[$ii] == '1') {

            //ACTUALIZAMOS EN EL ALMACEN ORIGEN
            $sql_update = "UPDATE almacen_general_resumen SET 
            total_stok=total_stok - $cantidad_trns[$ii], total_egreso=total_egreso+ $cantidad_trns[$ii], user_updated='$this->id_usr_sesion'         
            WHERE idalmacen_general_resumen='$idalmacen_general_resumen_trns[$ii]' 
            and idproducto='$idproducto_trns[$ii]' 
            and idalmacen_general='$idalmacen_general_trns[$ii]'";

            $sql_alm_detalle = ejecutarConsulta($sql_update,'U');
            if ($sql_alm_detalle['status'] == false) {
              return $sql_alm_detalle;
            }

            //REGISTRAMOS LA SALIDA DEL ALAMACEN ORIGEN
            $sql_create_det = "INSERT INTO almacen_general_detalle( idalmacen_general_resumen, idproyecto, tipo_mov, fecha,cantidad, user_created) 
            VALUES ('$idalmacen_general_resumen_trns[$ii]','$name_alm_proyecto','EGP','$fecha_transf_proy_alm','$cantidad_trns[$ii]','$this->id_usr_sesion')";
            $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

            if ($sql_alm_det_gen['status'] == false) {
              return $sql_alm_det_gen;
            }
            
            //REGISTRO  AL NUEVO ALMACEN DE PROYECTO

            //Verificamos si hay el producto en el almacen nuevo 
            $sql_verif = "SELECT * FROM almacen_resumen WHERE idproyecto='$name_alm_proyecto' and idproducto='$idproducto_trns[$ii]'";
            $r_verficar = ejecutarConsultaSimpleFila($sql_verif);

            if ($r_verficar['status'] == false) {
              return $r_verficar;
            }
            if (!empty($r_verficar['data'])) {

              $idalmacen_resumen_p = $r_verficar['data']['idalmacen_resumen'];
              $idproyecto_p           = $r_verficar['data']['idproyecto'];
              $id_producto_p = $r_verficar['data']['idproducto'];
            } else {
              $idalmacen_resumen_p = null;
              $idproyecto_p        = null;
              $id_producto_p       = null;
            }

            if (!empty($idalmacen_resumen_p) &&  !empty($idproyecto_p) && !empty($id_producto_p) && $idproyecto_p = $name_alm_proyecto  && $id_producto_p = $idproducto_trns[$ii]) {
              //  var_dump($idalmacen_general_r); die();
              //ACTUALIZAMOS EL QUE YA EXISTE
              $sql_update = "UPDATE almacen_resumen SET 
              total_stok=total_stok + $cantidad_trns[$ii], total_ingreso=total_ingreso + $cantidad_trns[$ii], 
              user_updated='$this->id_usr_sesion' WHERE idalmacen_resumen='$idalmacen_resumen_p'";

              $sql_alm_detalle = ejecutarConsulta($sql_update,'U');
              if ($sql_alm_detalle['status'] == false) {
                return $sql_alm_detalle;
              }

              //Registramos un nuevo detalle
              $sql_create_det = "INSERT INTO almacen_detalle( idalmacen_resumen, idalmacen_general, tipo_mov, fecha,cantidad, user_created) 
              VALUES ('$idalmacen_resumen_p','$idalmacen_general_origen','IPG','$fecha_transf_proy_alm','$cantidad_trns[$ii]','$this->id_usr_sesion')";
              $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

              if ($sql_alm_det_gen['status'] == false) {
                return $sql_alm_det_gen;
              }

            } else {

              //AGREGAMOS UNO NUEVO
              $sql_nuevo = "INSERT INTO almacen_resumen(idproyecto, idproducto, tipo, total_stok, total_ingreso, user_created) 
              VALUES ('$name_alm_proyecto','$idproducto_trns[$ii]','$tipo_trns[$ii]','$cantidad_trns[$ii]','$cantidad_trns[$ii]','$this->id_usr_sesion')";
              $sql_new_regist = ejecutarConsulta_retornarID($sql_nuevo,'C');

              if ($sql_new_regist['status'] == false) {
                return $sql_new_regist;
              }

              $idalmacen_resumen = $sql_new_regist['data'];

              //Registramos un nuevo detalle
              $sql_create_det = "INSERT INTO almacen_detalle( idalmacen_resumen, idalmacen_general,  tipo_mov, fecha,cantidad, user_created) 
              VALUES ('$idalmacen_resumen','$idalmacen_general_origen','IEA','$fecha_transf_proy_alm','$cantidad_trns[$ii]','$this->id_usr_sesion')";
              $sql_alm_det_gen = ejecutarConsulta($sql_create_det,'C');

              if ($sql_alm_det_gen['status'] == false) {
                return $sql_alm_det_gen;
              }
            }
          }
          $ii = $ii + 1;
        }
        return $retorno = ['status' => true, 'message' => 'todo oka ps', 'data' => ''];
      }
  
      // -----------------------------
      //ACTUALIZAR EL ALMACEN RESUMEN GENERAL
      //REGISTRAR EN EL DETALLE LA SALIDA
      //REGISTRAR EL INGRESO AL NUEVO ALMACEN 
      //rEGISTRAR EL DETALLE DEL INGRESO AL ALMACEN
    }

    return $retorno = ['status' => true, 'message' => 'todo oka ps', 'data' => ''];
  }

  //Implementar un método para listar los registros
  public function transferencia_a_proy_almacen($id_almacen)
  {
    $sql = "SELECT 
    agr.idalmacen_general_resumen,
    p.idproducto,
    agr.tipo,
    agr.total_stok,
    agr.total_ingreso,
    agr.total_egreso,
    ag.idalmacen_general,
    p.nombre as nombre_producto,
    um.nombre_medida as unidad_medida,
    um.abreviacion,
    c.nombre as categoria
    FROM almacen_general_resumen AS agr
    INNER JOIN almacen_general as ag on agr.idalmacen_general = ag.idalmacen_general
    INNER JOIN producto as p on agr.idproducto = p.idproducto
    INNER JOIN unidad_medida um on p.idunidad_medida=um.idunidad_medida
    INNER JOIN categoria_insumos_af c on p.idcategoria_insumos_af=c.idcategoria_insumos_af
    WHERE agr.idalmacen_general='$id_almacen' AND agr.estado = '1' AND agr.estado_delete = '1';";
    return ejecutarConsultaArray($sql);
  }

  public function select2_proyect_almacen($tipo_transf, $id_almacen_g)
  {
    // var_dump($tipo_transf);die();
    $sql_return = "";

    if ($tipo_transf == 'Proyecto') {
      $sql = "SELECT idproyecto as id ,nombre_proyecto,nombre_codigo as nombre FROM proyecto  ORDER BY idproyecto desc;";

      $sql_return = ejecutarConsulta($sql);
      if ($sql_return['status'] == false) {
        return $sql_return;
      }
    } else {
      $sql = "SELECT idalmacen_general  as id ,nombre_almacen as nombre 
      FROM almacen_general where  idalmacen_general<>'$id_almacen_g' AND estado = '1' AND estado_delete = '1'  ORDER BY idalmacen_general desc;";

      $sql_return = ejecutarConsulta($sql);
      if ($sql_return['status'] == false) {
        return $sql_return;
      }
    }
    return $sql_return;
  }
}
