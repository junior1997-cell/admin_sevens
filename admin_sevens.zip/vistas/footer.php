<!-- Footer -->
<footer class="main-footer">
  <strong id="copyright">Copyright &copy; 2021 - <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script> <a href="escritorio.php">SevensIngenieros.SAC</a>.</strong>
  Todos los derechos reservados  .
  <div class="float-right d-none d-sm-inline-block"><b>Version</b> 0.0.1</div>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->