var tabla_principal;
var host = window.location.host == 'localhost'? `http://localhost/admin_sevens/dist/docs/valorizacion/documento/` : `${window.location.origin}/dist/docs/valorizacion/documento/` ;

//Función que se ejecuta al inicio
function init() {

  $("#bloc_Tecnico").addClass("menu-open");

  $("#mTecnico").addClass("active");

  $("#lValorizacion").addClass("active bg-primary");

  $("#idproyecto").val(localStorage.getItem('nube_idproyecto'));

  listar_tbla_principal(localStorage.getItem('nube_idproyecto'));

  ver_quincenas(localStorage.getItem('nube_idproyecto'));  

  $("#guardar_registro").on("click", function (e) {  $("#submit-form-trabajador").submit(); });

  // Formato para telefono
  $("[data-mask]").inputmask();  

}

$("#doc7_i").click(function() {  $('#doc7').trigger('click'); });
$("#doc7").change(function(e) {  addImageApplication(e,$("#doc7").attr("id")) });

// Eliminamos el doc 6
function doc7_eliminar() {

	$("#doc7").val("");

	$("#doc7_ver").html('<img src="../dist/svg/doc_uploads.svg" alt="" width="50%" >');

	$("#doc7_nombre").html("");
}

function mostrar_form_table(estados) {

  if (estados=='1') {
    $('#tab-seleccione').hide(); 
    $('#tab-contenido').hide(); 
    $('#tab-info').show();
    $('#card-regresar').hide();
  } else {
    if (estados=='2') {
      $('#tab-seleccione').show(); 
      $('#tab-contenido').show(); 
      $('#tab-info').hide();
      $('#card-regresar').show();
    }    
  }
}

// ver las echas de quincenas
function ver_quincenas(nube_idproyecto) {

  $('#lista_quincenas').html('<i class="fas fa-spinner fa-pulse fa-2x"></i>'); //console.log(nube_idproyecto);

  $.post("../ajax/valorizacion.php?op=listarquincenas", { nube_idproyecto: nube_idproyecto }, function (e, status) {

    e =JSON.parse(e); console.log(e);    

    $('#lista_quincenas').html('');

    // VALIDAMOS LAS FECHAS DE QUINCENA
    if (e.data) {     
        
      if (e.data.fecha_valorizacion == "quincenal") {

        $(".h1-titulo").html("Valorización - Quincenal");

        var fecha = format_d_m_a(e.data.fecha_inicio);  
        
        var fecha_i = sumaFecha(0,fecha);
  
        var cal_quincena  =e.data.plazo/15; var i=0;  var cont=0;

        while (i <= cal_quincena) {

          cont = cont+1;
    
          var fecha_inicio = fecha_i;
          
          fecha = sumaFecha(14,fecha_inicio); 
  
          let fecha_ii = format_a_m_d(fecha_inicio); let fecha_ff = format_a_m_d(fecha);
          
          $('#lista_quincenas').append(` <button id="boton-${i}" type="button" class="mb-2 btn bg-gradient-info text-center" onclick="fecha_quincena('${fecha_ii}', '${fecha_ff}', '${i}');"><i class="far fa-calendar-alt"></i> Valorización ${cont}<br>${fecha_inicio} // ${fecha}</button>`)
          
          fecha_i = sumaFecha(1,fecha);
    
          i++;
        }
      } else {

        if (e.data.fecha_valorizacion == "mensual") {

          $(".h1-titulo").html("Valorización - Mensual");

          var fecha = format_d_m_a(e.data.fecha_inicio);  var fecha_f = ""; var fecha_i = ""; //e.data.fecha_inicio

          var cal_mes  = false; var i=0;  var cont=0;

          while (cal_mes == false) {

            cont = cont+1;

            fecha_i = fecha;

            fecha_f = sumaFecha(29, fecha_i);

            let val_fecha_f = new Date( format_a_m_d(fecha_f) ); let val_fecha_proyecto = new Date(e.data.fecha_fin);
            
            // console.log(fecha_f + ' - '+e.data.fecha_fin);

            $('#lista_quincenas').append(` <button id="boton-${i}" type="button" class="mb-2 btn bg-gradient-info text-center" onclick="fecha_quincena('${format_a_m_d(fecha_i)}', '${format_a_m_d(fecha_f)}', '${i}');"><i class="far fa-calendar-alt"></i> Valorización ${cont}<br>${fecha_i} // ${fecha_f}</button>`)
            
            if (val_fecha_f.getTime() >= val_fecha_proyecto.getTime()) { cal_mes = true; }else{ cal_mes = false;}

            fecha = sumaFecha(1,fecha_f);

            i++;
          }          

        } else {

          if (e.data.fecha_valorizacion == "al finalizar") {

            $(".h1-titulo").html("Valorización - Al finalizar");

            $('#lista_quincenas').append(` <button id="boton-0" type="button" class="mb-2 btn bg-gradient-info text-center" onclick="fecha_quincena('${e.data.fecha_inicio}', '${e.data.fecha_fin}', '0');"><i class="far fa-calendar-alt"></i> Valorización 1<br>${format_d_m_a(e.data.fecha_inicio)} // ${format_d_m_a(e.data.fecha_fin)}</button>`)

          } else {
            $('#lista_quincenas').html(`<div class="info-box shadow-lg w-600px"> 
              <span class="info-box-icon bg-danger"><i class="fas fa-exclamation-triangle"></i></span> 
              <div class="info-box-content"> 
                <span class="info-box-text">Alerta</span> 
                <span class="info-box-number">No has definido los bloques de fechas del proyecto. <br>Ingresa al ESCRITORIO y EDITA tu proyecto selecionado.</span> 
              </div> 
            </div>`);
          }
        }
      }     

    } else {
      $('#lista_quincenas').html('<div class="info-box shadow-lg w-300px">'+
        '<span class="info-box-icon bg-danger"><i class="fas fa-exclamation-triangle"></i></span>'+
        '<div class="info-box-content">'+
          '<span class="info-box-text">Alerta</span>'+
          '<span class="info-box-number">Las fechas del proyecto <br> es menor de 1 día.</span>'+
        '</div>'+
      '</div>');
    }    
    //console.log(fecha);
  });
}

//Función limpiar
function limpiar() {
  $("#doc7_ver").html('<img src="../dist/svg/doc_uploads.svg" alt="" width="50%" >');
  $("#doc7_nombre").html('');
  $("#doc_old_7").val(""); 
  $("#doc7").val(""); 

  // Limpiamos las validaciones
  $(".form-control").removeClass('is-valid');
  $(".form-control").removeClass('is-invalid');
  $(".error.invalid-feedback").remove();
}

//Función para guardar o editar
function guardaryeditar(e) {
  // e.preventDefault(); //No se activará la acción predeterminada del evento
  var formData = new FormData($("#form-valorizacion")[0]);

  $.ajax({
    url: "../ajax/valorizacion.php?op=guardaryeditar",
    type: "POST",
    data: formData,
    contentType: false,
    processData: false,
    success: function (e) {   
      try {
        e = JSON.parse(e);
        if (e.status == true) {	

          Swal.fire("Correcto!", "Documento guardado correctamente", "success");	
          limpiar();
          tabla_principal.ajax.reload(null, false);
          mostrar_form_table(2);
          fecha_quincena(localStorage.getItem('fecha_i'), localStorage.getItem('fecha_f'), localStorage.getItem('i'));
          $("#modal-agregar-valorizacion").modal("hide");

        }else{
          ver_errores(e);
        }
      } catch (err) { console.log('Error: ', err.message); toastr.error('<h5 class="font-size-16px">Error temporal!!</h5> puede intentalo mas tarde, o comuniquese con <i><a href="tel:+51921305769" >921-305-769</a></i> ─ <i><a href="tel:+51921487276" >921-487-276</a></i>'); }      
      $("#guardar_registro").html('Guardar Cambios').removeClass('disabled');
    },
    xhr: function () {
      var xhr = new window.XMLHttpRequest();
      xhr.upload.addEventListener("progress", function (evt) {
        if (evt.lengthComputable) {
          var percentComplete = (evt.loaded / evt.total)*100;
          /*console.log(percentComplete + '%');*/
          $("#barra_progress").css({"width": percentComplete+'%'});
          $("#barra_progress").text(percentComplete.toFixed(2)+" %");
        }
      }, false);
      return xhr;
    },
    beforeSend: function () {
      $("#guardar_registro").html('<i class="fas fa-spinner fa-pulse fa-lg"></i>').addClass('disabled');
      $("#barra_progress").css({ width: "0%",  });
      $("#barra_progress").text("0%").addClass('progress-bar-striped progress-bar-animated');
    },
    complete: function () {
      $("#barra_progress").css({ width: "0%", });
      $("#barra_progress").text("0%").removeClass('progress-bar-striped progress-bar-animated');
    },
    error: function (jqXhr) { ver_errores(jqXhr); },
  });
}

function l_m(){  
  $("#barra_progress").css({"width":'0%'});  
  $("#barra_progress").text("0%");  
}

//Función Listar - tabla principal
function listar_tbla_principal(nube_idproyecto) {

  tabla_principal = $('#tabla-principal').dataTable({
    responsive: true,
    lengthMenu: [[-1, 5, 10, 25, 75, 100, 200, ], ["Todos", 5, 10, 25, 75, 100, 200, ]],//mostramos el menú de registros a revisar
    aProcessing: true,//Activamos el procesamiento del datatables
    aServerSide: true,//Paginación y filtrado realizados por el servidor
    dom: '<Bl<f>rtip>',//Definimos los elementos del control de tabla
    buttons: [{ extend: 'copyHtml5', footer: true }, { extend: 'excelHtml5', footer: true }, { extend: 'pdfHtml5', footer: true }, "colvis"],
    ajax:{
      url: `../ajax/valorizacion.php?op=listar_tbla_principal&nube_idproyecto=${nube_idproyecto}`,
      type : "get",
      dataType : "json",						
      error: function(e){
        console.log(e.responseText);	ver_errores(e);
      }
    },
    createdRow: function (row, data, ixdex) {
      // columna: sueldo mensual
      if (data[0] != '') { $("td", row).eq(0).addClass('text-nowrap'); }           
    },
    language: {
      lengthMenu: "Mostrar: _MENU_ registros",
      buttons: {
        copyTitle: "Tabla Copiada",
        copySuccess: {
          _: '%d líneas copiadas',
          1: '1 línea copiada'
        }
      },
      sLoadingRecords: '<i class="fas fa-spinner fa-pulse fa-lg"></i> Cargando datos...'
    },
    bDestroy: true,
    iDisplayLength: 10,//Paginación
    order: [[ 0, "asc" ]]//Ordenar (columna,orden)
  }).DataTable();  
}

function modal_comprobante(doc_valorizacion, indice, nombre, numero_q_s,) {
  $(".nombre_documento").html("");
  // exraemos la fecha de HOY
  var tiempoTranscurrido = Date.now();
  var hoy = new Date(tiempoTranscurrido);
  var format = hoy.toLocaleDateString().split("/"); //console.log(format);
  $(".nombre_documento").html(`${indice} ${nombre} - ${localStorage.getItem('nube_nombre_proyecto')} -  valorización ${numero_q_s}`);
  $("#modal-ver-comprobante").modal("show");

  if (doc_valorizacion=='' || doc_valorizacion==null) {
    $('#ver-documento').html(
      `<div class="col-lg-6"><a class="btn btn-warning btn-block btn-xs disabled" type="button" href="#"><i class="fas fa-download"></i> Descargar</a></div>
      <div class="col-lg-6 mb-4"><a class="btn btn-info btn-block btn-xs disabled" href="#" type="button"><i class="fas fa-expand"></i> Ver completo</a></div>
      <div class="col-lg-12 ">
        <div class="embed-responsive" style="padding-bottom:30%" >
          <div class="alert alert-warning alert-dismissible">
            <button type="button" class="close" data-dismiss="Alerta" aria-hidden="true">×</button><h5><i class="icon fas fa-exclamation-triangle"></i> Alerta!</h5>
            No hay un documento para ver. Edite este registro y vuelva a intentar.
          </div>
        </div>
      </div>`
    );
  } else {
    if (UrlExists(`${host}${doc_valorizacion}`) == 200) {
      var tipo_doc = doc_view_extencion(doc_valorizacion, 'valorizacion', 'documento', '100%', '400');

      $('#ver-documento').html(`
        <div class="col-lg-6">
          <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${doc_valorizacion}" download="${replace_punto_a_guion(indice)} ${nombre} - ${localStorage.getItem('nube_nombre_proyecto')} - Val${numero_q_s} - ${format[0]}-${format[1]}-${format[2]}" >
            <i class="fas fa-download"></i> Descargar
          </a>
        </div>
        <div class="col-lg-6 mb-4">
          <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${doc_valorizacion}"  target="_blank" type="button" >
            <i class="fas fa-expand"></i> Ver completo
          </a>
        </div>
        <div class="col-lg-12 text-center"> ${tipo_doc} </div>`
      );  
    } else {
      $('#ver-documento').html(
        `<div class="col-lg-6"><a class="btn btn-warning btn-block btn-xs disabled" type="button" href="#"><i class="fas fa-download"></i> Descargar</a></div>
        <div class="col-lg-6 mb-4"><a class="btn btn-info btn-block btn-xs disabled" href="#" type="button"><i class="fas fa-expand"></i> Ver completo</a></div>
        <div class="col-lg-12 ">
          <div class="embed-responsive" style="padding-bottom:30%" >
            <div class="alert alert-warning alert-dismissible">
              <button type="button" class="close" data-dismiss="Alerta" aria-hidden="true">×</button><h5><i class="icon fas fa-exclamation-triangle"></i> Alerta!</h5>
              El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar.
            </div>
          </div>
        </div>`
      );
    }      
  }
}

function editar(idtabla, indice, nombre, doc, fecha_i, fecha_f, numero_q_s) {
  limpiar();
  $('#title-modal-1').html(indice+' '+nombre);

 // $("#idproyecto").val();
  $("#idvalorizacion").val(idtabla);
  $("#indice").val(indice);
  $("#nombre").val(nombre);
  $("#fecha_inicio").val(fecha_i);
  $("#fecha_fin").val(fecha_f);
  $("#numero_q_s").val(numero_q_s);

  $("#modal-agregar-valorizacion").modal('show'); 

  if (doc != "") {

    $("#doc_old_7").val(doc);    
    // cargamos la imagen adecuada par el archivo
    $("#doc7_ver").html(doc_view_extencion(doc, 'valorizacion', 'documento', '100%', '210'));    
  }
}

function eliminar(nombre_eliminar, nombre_tabla, nombre_columna, idtabla) {
  crud_eliminar_papelera(
    `../ajax/valorizacion.php?op=desactivar&nombre_tabla=${nombre_tabla}&nombre_columna=${nombre_columna}`,
    `../ajax/valorizacion.php?op=eliminar&nombre_tabla=${nombre_tabla}&nombre_columna=${nombre_columna}`, 
    idtabla, 
    "!Elija una opción¡", 
    `<b class="text-danger">${nombre_eliminar}</b> <br> En <b>papelera</b> encontrará este registro! <br> Al <b>eliminar</b> no tendrá acceso a recuperar este registro!`, 
    function(){ sw_success('♻️ Papelera! ♻️', "Tu registro ha sido reciclado." ) }, 
    function(){ sw_success('Eliminado!', 'Tu registro ha sido Eliminado.' ) }, 
    function(){ tabla_principal.ajax.reload(null, false) },
    false, 
    false, 
    false,
    false
  );
}


init();

// .....::::::::::::::::::::::::::::::::::::: V A L I D A T E   F O R M  :::::::::::::::::::::::::::::::::::::::..

$(function () {  

  $("#form-valorizacion").validate({

    rules: {
      nombre: { required: true },
    },

    messages: {
      nombre: {
        required: "Por favor selecione un tipo de documento", 
      },       
    },
        
    errorElement: "span",

    errorPlacement: function (error, element) {
      error.addClass("invalid-feedback");
      element.closest(".form-group").append(error);
    },

    highlight: function (element, errorClass, validClass) {
      $(element).addClass("is-invalid").removeClass("is-valid");
    },

    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass("is-invalid").addClass("is-valid");
    },

    submitHandler: function (e) {
      $(".modal-body").animate({ scrollTop: $(document).height() }, 600); // Scrollea hasta abajo de la página
      guardaryeditar(e);
    },

  });
});

// .....::::::::::::::::::::::::::::::::::::: F U N C I O N E S    A L T E R N A S  :::::::::::::::::::::::::::::::::::::::..

// captura las fechas de quincenas y trae los datos
function fecha_quincena(fecha_i, fecha_f, i) {

  $('.icon-resumen-cargando').html('<i class="fas fa-spinner fa-pulse fa-md"></i>');

  var cont_valor = parseInt(i) + 1;
  //console.log(cont_valor);
  $("#nombre_titulo").html("Valorización " + cont_valor);

  localStorage.setItem('fecha_i', fecha_i);  localStorage.setItem('fecha_f', fecha_f); localStorage.setItem('i', i);

  let nube_idproyecto = localStorage.getItem('nube_idproyecto');

  var respuestadoc5_2 = false;
  mostrar_form_table(2);
 
  $("#fecha_inicio").val(fecha_i);
  $("#fecha_fin").val(fecha_f);  //console.log(fecha_i, fecha_f, i);
  $("#numero_q_s").val(cont_valor);

  // validamos el id para pintar el boton
  if (localStorage.getItem('boton_id')) {

    let id = localStorage.getItem('boton_id'); //console.log('id-nube-boton'+id); 
    
    $("#boton-" + id).removeClass('click-boton');

    localStorage.setItem('boton_id', i);

    $("#boton-"+i).addClass('click-boton');
  } else {

    localStorage.setItem('boton_id', i);

    $("#boton-"+i).addClass('click-boton');
  }

  // pintamos rojos los que no tienen docs
  $("#tabs-2-tab").addClass('no-doc').removeClass('si-doc');   
  $("#tabs-3-1-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-3-2-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-3-3-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-3-4-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-5-1-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-5-2-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-6-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-7-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-8-4-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-8-5-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-8-6-tab").addClass('no-doc').removeClass('si-doc');
  $("#tabs-8-7-tab").addClass('no-doc').removeClass('si-doc');

  $('#documento2').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento3-1').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento3-2').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento3-3').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento3-4').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento5-1').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento5-2').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc_respuesta('','5.2');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:30%" > No hay documento para mostrar </div> </div>` );
  $('#documento5-2-1').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc_respuesta('','5.2.1');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:30%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento6').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento7').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento8-4').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento8-5').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento8-6').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 
  $('#documento8-7').html(`<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc('');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>` ); 


  // traemos loa documentos por fechas de la quincena
  $.post("../ajax/valorizacion.php?op=mostrar-docs-quincena", { nube_idproyecto: nube_idproyecto, fecha_i: fecha_i, fecha_f: fecha_f }, function (e, status) {

    e =JSON.parse(e); console.log(e);  
    
    var vacio = "''";  var docs_total = 0; var porcent = 0;

    // validamos la data total
    if (e.status == true) {
      
      // exraemos la fecha de HOY
      var tiempoTranscurrido = Date.now();
      var hoy = new Date(tiempoTranscurrido);
      var format = hoy.toLocaleDateString().split("/"); //console.log(format);
      
      // validamos la data1
      if (e.data.data1.length === 0) { console.log('data 1 no existe'); } else {
        //console.log('data 1 existe');
        
        $.each(e.data.data1, function (index, value) {

          if (value.indice == "2" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-2-tab").removeClass('no-doc').addClass("si-doc");      
              
              // cargamos la imagen adecuada par el archivo
              $('#documento2').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="2 Informe tecnico - ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );  
              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento2').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              ); 
            }
          }

          if (value.indice == "3.1" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-3-1-tab").removeClass('no-doc').addClass("si-doc");         
    
              // cargamos la imagen adecuada par el archivo
              $('#documento3-1').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="3-1 Planilla de metrados -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );    
              
              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento3-1').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "3.2" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-3-2-tab").removeClass('no-doc').addClass("si-doc");   
    
              // cargamos la imagen adecuada par el archivo
              $('#documento3-2').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="3-2 Valorizaciones -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              ); 

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);  
            } else {
              $('#documento3-2').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }                 
          }

          if (value.indice == "3.3" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-3-3-tab").removeClass('no-doc').addClass("si-doc"); 
    
              // cargamos la imagen adecuada par el archivo
              $('#documento3-3').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="3-3 Resumen de valorizacion -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );  

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento3-3').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "3.4" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-3-4-tab").removeClass('no-doc').addClass("si-doc");     
    
              // cargamos la imagen adecuada par el archivo
              $('#documento3-4').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="3-4 Curva S -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );  
              
              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento3-4').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "5.1" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-5-1-tab").removeClass('no-doc').addClass("si-doc");        
    
              // cargamos la imagen adecuada par el archivo
              $('#documento5-1').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="5-1 Ensayo de consi. del concreto -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );  

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento5-1').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "5.2" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-5-2-tab").removeClass('no-doc').addClass("si-doc");        
              
              // cargamos la imagen adecuada par el archivo
              $('#documento5-2').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc_respuesta(${value.idvalorizacion},'5.2');">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="5-2 Ensayo de compresión -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento5-2').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "5.2.1" ) {  
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // cargamos la imagen adecuada par el archivo
              $('#documento5-2-1').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success btn-block btn-xs" type="button" onclick="subir_doc_respuesta(${value.idvalorizacion}, '5.2.1');">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="5-2-1 Respuesta de ensayo de compresión -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );    

              // mostramos el resumen
              // docs_total += 1;
              // porcent = (docs_total * 100 )/18;
              // $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              // $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              // $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);               
            } else {
              $('#documento5-2-1').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }
            respuestadoc5_2 = true;
          }

          if (value.indice == "6" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-6-tab").removeClass('no-doc').addClass("si-doc");        
    
              // cargamos la imagen adecuada par el archivo
              $('#documento6').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/${value.doc_valorizacion}" download="6 Plan de seg y salud en el trabajo -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '700')}
                </div>`
              );   
              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);      
            } else {
              $('#documento6').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "7"  ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-7-tab").removeClass('no-doc').addClass("si-doc");       
    
              // cargamos la imagen adecuada par el archivo
              $('#documento7').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="7 Plan de bioseguridad COVID19 -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '100%')}
                </div>`
              );   
              
              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento7').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "8.4" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-8-4-tab").removeClass('no-doc').addClass("si-doc");        
    
              // cargamos la imagen adecuada par el archivo
              $('#documento8-4').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="8-4 Planilla del personal obrero -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '100%')}
                </div>`
              );  

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento8-4').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }                   
          }

          if (value.indice == "8.5" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-8-5-tab").removeClass('no-doc').addClass("si-doc");      
    
              // cargamos la imagen adecuada par el archivo
              $('#documento8-5').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="8-5 Copia del seguro complement contra todo riesgo -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '100%')}
                </div>`
              );   

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
            } else {
              $('#documento8-5').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }                 
          }

          if (value.indice == "8.6" ) {
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-8-6-tab").removeClass('no-doc').addClass("si-doc");       
    
              // cargamos la imagen adecuada par el archivo
              $('#documento8-6').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="8-6 Panel fotográfico -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '100%')}
                </div>`
              );   

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);    
            } else {
              $('#documento8-6').html(
                `<div class="col-lg-4"> <a class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }            
          }

          if (value.indice == "8.7" ) {
            //console.log('entramos');
            if (UrlExists(`${host}${value.doc_valorizacion}`) == 200) {
              // pintamos rojos los que no tienen docs
              $("#tabs-8-7-tab").removeClass('no-doc').addClass("si-doc");     
    
              // cargamos la imagen adecuada par el archivo
              $('#documento8-7').html(
                `<div class="col-lg-4">
                  <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});">
                    <i class="fas fa-file-upload"></i> Subir
                  </a>
                </div>
                <div class="col-lg-4">
                  <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}" download="8-7 Copia del cuaderno de obra -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                    <i class="fas fa-download"></i> Descargar
                  </a>
                </div>
                <div class="col-lg-4 mb-4">
                  <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${value.doc_valorizacion}"  target="_blank"  type="button" >
                    <i class="fas fa-expand"></i> Ver completo
                  </a>
                </div>
                <div class="col-lg-12 text-center">
                  ${doc_view_extencion(value.doc_valorizacion, 'valorizacion', 'documento', '100%', '100%')}
                </div>`
              );    

              // mostramos el resumen
              docs_total += 1;
              porcent = (docs_total * 100 )/18;
              $('.total_docs_subidos').html(`Total ${docs_total}/18`);
              $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
              $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`); 
            } else {
              //console.log('entramos 2');
              $('#documento8-7').html(
                `<div class="col-lg-4"> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${value.idvalorizacion});"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a class="btn btn-warning btn-block btn-xs" type="button" href="#" download="#"> <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs" href="#" target="_blank" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> El documento no esta disponible, porbablemente esta <b>eliminado</b> o se a <b>movido</b> a otra carpeta. Edite este registro y vuelva a intentar. </div>`
              );
            }               
          }
          
        });

        if (respuestadoc5_2 == false) { $('#documento5-2-1').html(`<div class="col-lg-4 "> <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc_respuesta(${vacio}, '5.2.1');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning  btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a> </div> <div class="col-lg-4 mb-4"> <a  class="btn btn-info  btn-block btn-xs disabled" href="#" type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:30%" > No hay documento para mostrar </div> </div>` ); }
      }

      // validamos la data2
      if (e.data.data2.length === 0) {
        console.log('data 2 no existe');
      } else {

        if (e.data.data2.doc1 != "" && UrlExists(`${host}${e.data.data2.doc1}`) == 200) {

          if ($("#tabs-1-tab").hasClass("no-doc")) { $("#tabs-1-tab").removeClass('no-doc'); }          

          // cargamos la imagen adecuada par el archivo
          $('#documento1').html(
            `<div class="col-lg-4">
              <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${e.data.data2.idproyecto});">
                <i class="fas fa-file-upload"></i> Subir
              </a>
            </div>
            <div class="col-lg-4">
              <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${e.data.data2.doc1}" download="1 Copia del contrato -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                <i class="fas fa-download"></i> Descargar
              </a>
            </div>
            <div class="col-lg-4 mb-4">
              <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${e.data.data2.doc1}"  target="_blank"  type="button" >
                <i class="fas fa-expand"></i> Ver completo
              </a>
            </div>
            <div class="col-lg-12 text-center">
              ${doc_view_extencion(e.data.data2.doc1, 'valorizacion', 'documento', '100%', '700')}
            </div>`
          );

          // mostramos el resumen
          docs_total += 1;
          porcent = (docs_total * 100 )/18;
          $('.total_docs_subidos').html(`Total ${docs_total}/18`);
          $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
          $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);
        
        } else {

          if ($("#tabs-1-tab").hasClass("no-doc") == false) { $("#tabs-1-tab").addClass('no-doc'); }

          $('#documento1').html('<div class="col-lg-4"> <a  class="btn btn-success btn-block btn-xs" type="button" onclick="subir_doc('+e.data.data2.idproyecto+');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a></div> <div class="col-lg-4 mb-4"><a  class="btn btn-info  btn-block btn-xs disabled" href="#"  target="_blank"  type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>' );
        }

        if (e.data.data2.doc4 != "" && UrlExists(`${host}${e.data.data2.doc4}`) == 200) {

          if ($("#tabs-4-tab").hasClass("no-doc")) { $("#tabs-4-tab").removeClass('no-doc'); }           

          // cargamos la imagen adecuada par el archivo
          $('#documento4').html(
            `<div class="col-lg-4">
              <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${e.data.data2.idproyecto});">
                <i class="fas fa-file-upload"></i> Subir
              </a>
            </div>
            <div class="col-lg-4">
              <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${e.data.data2.doc4}" download="4 Cronograma de obra valorizado -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                <i class="fas fa-download"></i> Descargar
              </a>
            </div>
            <div class="col-lg-4 mb-4">
              <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${e.data.data2.doc4}"  target="_blank"  type="button" >
                <i class="fas fa-expand"></i> Ver completo
              </a>
            </div>
            <div class="col-lg-12 text-center">
            ${doc_view_extencion(e.data.data2.doc4, 'valorizacion', 'documento', '100%', '700')}
            </div>`
          );

          // mostramos el resumen
          docs_total += 1;
          porcent = (docs_total * 100 )/18;
          $('.total_docs_subidos').html(`Total ${docs_total}/18`);
          $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
          $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);

        } else {

          if ($("#tabs-4-tab").hasClass("no-doc") == false) { $("#tabs-4-tab").addClass('no-doc'); }

          $('#documento4').html('<div class="col-lg-4"> <a  class="btn btn-success btn-block btn-xs" type="button" onclick="subir_doc('+e.data.data2.idproyecto+');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a></div> <div class="col-lg-4 mb-4"><a  class="btn btn-info  btn-block btn-xs disabled" href="#"  target="_blank"  type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>' );
        }

        if (e.data.data2.doc81 != "" && UrlExists(`${host}${e.data.data2.doc81}`) == 200) {

          if ($("#tabs-8-1-tab").hasClass("no-doc")) { $("#tabs-8-1-tab").removeClass('no-doc'); }

          // cargamos la imagen adecuada par el archivo
          $('#documento8-1').html(
            `<div class="col-lg-4">
              <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${e.data.data2.idproyecto});">
                <i class="fas fa-file-upload"></i> Subir
              </a>
            </div>
            <div class="col-lg-4">
              <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${e.data.data2.doc81}" download="8-1 Acta de entrega de terreno -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                <i class="fas fa-download"></i> Descargar
              </a>
            </div>
            <div class="col-lg-4 mb-4">
              <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${e.data.data2.doc81}"  target="_blank"  type="button" >
                <i class="fas fa-expand"></i> Ver completo
              </a>
            </div>
            <div class="col-lg-12 text-center">
              ${doc_view_extencion(e.data.data2.doc81, 'valorizacion', 'documento', '100%', '700')}
            </div>`
          );

          // mostramos el resumen
          docs_total += 1;
          porcent = (docs_total * 100 )/18;
          $('.total_docs_subidos').html(`Total ${docs_total}/18`);
          $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
          $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);

        } else {

          if ($("#tabs-8-1-tab").hasClass("no-doc") == false) { $("#tabs-8-1-tab").addClass('no-doc'); }

          $('#documento8-1').html('<div class="col-lg-4"> <a  class="btn btn-success btn-block btn-xs" type="button" onclick="subir_doc('+e.data.data2.idproyecto+');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a></div> <div class="col-lg-4 mb-4"><a  class="btn btn-info  btn-block btn-xs disabled" href="#"  target="_blank"  type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>' );
        }

        if (e.data.data2.doc82 != "" && UrlExists(`${host}${e.data.data2.doc82}`) == 200) {

          if ($("#tabs-8-2-tab").hasClass("no-doc")) { $("#tabs-8-2-tab").removeClass('no-doc'); }

          // cargamos la imagen adecuada par el archivo
          $('#documento8-2').html(
            `<div class="col-lg-4">
              <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${e.data.data2.idproyecto});">
                <i class="fas fa-file-upload"></i> Subir
              </a>
            </div>
            <div class="col-lg-4">
              <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${e.data.data2.doc82}" download="8-2 Acta de inicio de obra -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                <i class="fas fa-download"></i> Descargar
              </a>
            </div>
            <div class="col-lg-4 mb-4">
              <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${e.data.data2.doc82}"  target="_blank"  type="button" >
                <i class="fas fa-expand"></i> Ver completo
              </a>
            </div>
            <div class="col-lg-12 text-center">
              ${doc_view_extencion(e.data.data2.doc82, 'valorizacion', 'documento', '100%', '700')}
            </div>`
          );

          // mostramos el resumen
          docs_total += 1;
          porcent = (docs_total * 100 )/18;
          $('.total_docs_subidos').html(`Total ${docs_total}/18`);
          $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
          $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);

        } else {

          if ($("#tabs-8-2-tab").hasClass("no-doc") == false) { $("#tabs-8-2-tab").addClass('no-doc'); }

          $('#documento8-2').html('<div class="col-lg-4"> <a  class="btn btn-success btn-block btn-xs" type="button" onclick="subir_doc('+e.data.data2.idproyecto+');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a></div> <div class="col-lg-4 mb-4"><a  class="btn btn-info  btn-block btn-xs disabled" href="#"  target="_blank"  type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>' );
        }

        if (e.data.data2.doc83 != "" && UrlExists(`${host}${e.data.data2.doc83}`) == 200) {

          if ($("#tabs-8-3-tab").hasClass("no-doc")) { $("#tabs-8-3-tab").removeClass('no-doc'); }

          // cargamos la imagen adecuada par el archivo
          $('#documento8-3').html(
            `<div class="col-lg-4">
              <a  class="btn btn-success  btn-block btn-xs" type="button" onclick="subir_doc(${e.data.data2.idproyecto});">
                <i class="fas fa-file-upload"></i> Subir
              </a>
            </div>
            <div class="col-lg-4">
              <a  class="btn btn-warning  btn-block btn-xs" type="button" href="../dist/docs/valorizacion/documento/${e.data.data2.doc83}" download="8-3 Certif de habil del ing resident -  ${localStorage.getItem('nube_nombre_proyecto')} - Val${cont_valor} - ${format[0]}-${format[1]}-${format[2]}" >
                <i class="fas fa-download"></i> Descargar
              </a>
            </div>
            <div class="col-lg-4 mb-4">
              <a  class="btn btn-info  btn-block btn-xs" href="../dist/docs/valorizacion/documento/${e.data.data2.doc83}"  target="_blank"  type="button" >
                <i class="fas fa-expand"></i> Ver completo
              </a>
            </div>
            <div class="col-lg-12 text-center">
              ${doc_view_extencion(e.data.data2.doc83, 'valorizacion', 'documento', '100%', '700')}
            </div>`
          ); 

          // mostramos el resumen
          docs_total += 1;
          porcent = (docs_total * 100 )/18;
          $('.total_docs_subidos').html(`Total ${docs_total}/18`);
          $('.porcentaje_progress').css({'width': `${porcent.toFixed(1)}%`});
          $('.porcentaje_numero').html(`${porcent.toFixed(1)} %`);

        } else {

          if ($("#tabs-8-3-tab").hasClass("no-doc") == false) { $("#tabs-8-3-tab").addClass('no-doc'); }

          $('#documento8-3').html('<div class="col-lg-4"> <a  class="btn btn-success btn-block btn-xs" type="button" onclick="subir_doc('+e.data.data2.idproyecto+');"> <i class="fas fa-file-upload"></i> Subir </a> </div> <div class="col-lg-4"> <a  class="btn btn-warning btn-block btn-xs disabled" type="button" href="#" > <i class="fas fa-download"></i> Descargar </a></div> <div class="col-lg-4 mb-4"><a  class="btn btn-info  btn-block btn-xs disabled" href="#"  target="_blank"  type="button" > <i class="fas fa-expand"></i> Ver completo </a> </div> <div class="col-lg-12 "> <div class="embed-responsive disenio-scroll" style="padding-bottom:90%" > No hay documento para mostrar </div> </div>' );
        }
      }

    } else {
      ver_errores(e);
    }
    // $('#lista_quincenas').html('');
    $('.icon-resumen-cargando').html('<i class="far fa-bookmark"></i>');

  }).fail( function(e) { ver_errores(e); } );
}

function add_data_form(indice,nom_title) {
  $("#indice").val(indice); 
  $("#nombre").val(nom_title); 

  $('#title-modal-1').html(nom_title);

  //console.log(nombredoc);  
}

//Función para desactivar registros
function subir_doc(idvalorizacion) {

  //console.log('idvalorizacion: ' + idvalorizacion);

  $("#idvalorizacion").val(idvalorizacion);

  $("#modal-agregar-valorizacion").modal('show'); 
}

function subir_doc_respuesta(idvalorizacion, indice) {

  $("#idvalorizacion").val(idvalorizacion);

  $("#indice").val(indice);
  
  $("#modal-agregar-valorizacion").modal('show'); 
}

function sumar_mes(fecha) {

  var split_fecha =  fecha.split("-");

  // var format_fecha = format_d_m_a(fecha);

  var dias_total_mes = cantDiasEnUnMes( parseInt(split_fecha[1]), parseInt(split_fecha[0]) );  

  var mes_next =  sumaFecha(dias_total_mes-1, fecha); 

  // console.log(`🚀 ${fecha} + ${dias_total_mes-1} =  fecha_f:${mes_next}`);  

  return mes_next;
}

function cantDiasEnUnMes(mes, año) {
   
  var diasMes = new Date(año, mes, 0).getDate(); // console.log('mes:' + mes+ ' cant:' + diasMes);

  return diasMes; 
}

function despintar_btn_select() {  
  if (localStorage.getItem('boton_id')) { let id = localStorage.getItem('boton_id'); $("#boton-" + id).removeClass('click-boton'); }
}
