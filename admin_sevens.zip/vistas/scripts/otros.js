$("#bloc_Recurso").addClass("menu-open bg-color-191f24");

$("#mRecurso").addClass("active");

$("#lOtros").addClass("active");